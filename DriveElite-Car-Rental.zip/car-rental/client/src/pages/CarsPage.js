import React, { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import { getCars, createCar, updateCar, deleteCar } from '../utils/api';
import './CarsPage.css';

const CAR_CATEGORIES = ['Sedan','SUV','Sports','Luxury','Electric','Van','Truck','Convertible'];
const STATUSES = ['available','rented','maintenance','reserved'];
const FUELS = ['Gasoline','Diesel','Electric','Hybrid'];
const TRANSMISSIONS = ['Automatic','Manual'];

const emptyForm = { name:'', brand:'', model:'', year: new Date().getFullYear(), category:'Sedan', licensePlate:'', dailyRate:'', status:'available', color:'', seats:5, transmission:'Automatic', fuel:'Gasoline', mileage:0, description:'', features:'' };

const carColorMap = { Sedan:'#4361EE', SUV:'#FFB800', Sports:'#E63946', Luxury:'#00D4AA', Electric:'#7B2FBE', Van:'#FF6B35', Truck:'#2196F3', Convertible:'#E91E63' };

function CarModal({ car, onClose, onSave }) {
  const [form, setForm] = useState(car ? { ...car, features: Array.isArray(car.features) ? car.features.join(', ') : '' } : emptyForm);
  const [loading, setLoading] = useState(false);

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = { ...form, features: form.features ? form.features.split(',').map(f => f.trim()).filter(Boolean) : [] };
      let saved;
      if (car?._id) { const r = await updateCar(car._id, payload); saved = r.data.data; }
      else { const r = await createCar(payload); saved = r.data.data; }
      onSave(saved, !!car?._id);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save car');
    } finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <h3>{car ? 'Edit Vehicle' : 'Add New Vehicle'}</h3>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-grid">
              <div className="form-group"><label className="form-label">Vehicle Name *</label><input className="form-input" value={form.name} onChange={e=>set('name',e.target.value)} required placeholder="e.g. Tesla Model S" /></div>
              <div className="form-group"><label className="form-label">Brand *</label><input className="form-input" value={form.brand} onChange={e=>set('brand',e.target.value)} required placeholder="e.g. Tesla" /></div>
              <div className="form-group"><label className="form-label">Model *</label><input className="form-input" value={form.model} onChange={e=>set('model',e.target.value)} required placeholder="e.g. Model S" /></div>
              <div className="form-group"><label className="form-label">Year *</label><input className="form-input" type="number" value={form.year} onChange={e=>set('year',e.target.value)} required min="1990" max="2026" /></div>
              <div className="form-group"><label className="form-label">License Plate *</label><input className="form-input" value={form.licensePlate} onChange={e=>set('licensePlate',e.target.value.toUpperCase())} required placeholder="AB-123-23" /></div>
              <div className="form-group"><label className="form-label">Daily Rate ($) *</label><input className="form-input" type="number" value={form.dailyRate} onChange={e=>set('dailyRate',e.target.value)} required min="0" /></div>
              <div className="form-group"><label className="form-label">Category *</label><select className="form-input" value={form.category} onChange={e=>set('category',e.target.value)}>{CAR_CATEGORIES.map(c=><option key={c}>{c}</option>)}</select></div>
              <div className="form-group"><label className="form-label">Status</label><select className="form-input" value={form.status} onChange={e=>set('status',e.target.value)}>{STATUSES.map(s=><option key={s}>{s}</option>)}</select></div>
              <div className="form-group"><label className="form-label">Color *</label><input className="form-input" value={form.color} onChange={e=>set('color',e.target.value)} required placeholder="e.g. Midnight Black" /></div>
              <div className="form-group"><label className="form-label">Seats *</label><input className="form-input" type="number" value={form.seats} onChange={e=>set('seats',e.target.value)} required min="1" max="20" /></div>
              <div className="form-group"><label className="form-label">Transmission</label><select className="form-input" value={form.transmission} onChange={e=>set('transmission',e.target.value)}>{TRANSMISSIONS.map(t=><option key={t}>{t}</option>)}</select></div>
              <div className="form-group"><label className="form-label">Fuel Type</label><select className="form-input" value={form.fuel} onChange={e=>set('fuel',e.target.value)}>{FUELS.map(f=><option key={f}>{f}</option>)}</select></div>
              <div className="form-group"><label className="form-label">Mileage (km)</label><input className="form-input" type="number" value={form.mileage} onChange={e=>set('mileage',e.target.value)} min="0" /></div>
              <div className="form-group"><label className="form-label">Location</label><input className="form-input" value={form.location||''} onChange={e=>set('location',e.target.value)} placeholder="Main Branch" /></div>
              <div className="form-group form-group--full"><label className="form-label">Features (comma-separated)</label><input className="form-input" value={form.features} onChange={e=>set('features',e.target.value)} placeholder="GPS, Heated Seats, Sunroof" /></div>
              <div className="form-group form-group--full"><label className="form-label">Description</label><textarea className="form-input" rows={3} value={form.description||''} onChange={e=>set('description',e.target.value)} placeholder="Vehicle description..." style={{resize:'vertical'}} /></div>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Saving...' : (car ? 'Update Vehicle' : 'Add Vehicle')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function DeleteModal({ car, onClose, onConfirm, loading }) {
  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 420 }}>
        <div className="modal-header"><h3>Delete Vehicle</h3><button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button></div>
        <div className="modal-body">
          <div className="delete-confirm">
            <div className="delete-confirm__icon">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#E63946" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
              </svg>
            </div>
            <p>Are you sure you want to delete <strong>{car.name}</strong>? This action cannot be undone.</p>
          </div>
        </div>
        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn btn-danger" onClick={onConfirm} disabled={loading}>
            {loading ? 'Deleting...' : 'Delete Vehicle'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function CarsPage() {
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [modal, setModal] = useState(null); // null | 'add' | 'edit' | 'delete'
  const [selected, setSelected] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [pagination, setPagination] = useState({ page: 1, pages: 1, total: 0 });

  const fetchCars = useCallback(async (page = 1) => {
    setLoading(true);
    try {
      const params = { page, limit: 12 };
      if (search) params.search = search;
      if (statusFilter) params.status = statusFilter;
      if (categoryFilter) params.category = categoryFilter;
      const res = await getCars(params);
      setCars(res.data.data);
      setPagination(res.data.pagination);
    } catch (e) {
      toast.error('Failed to load cars');
    } finally { setLoading(false); }
  }, [search, statusFilter, categoryFilter]);

  useEffect(() => { fetchCars(); }, [fetchCars]);

  const handleSave = (saved, isEdit) => {
    if (isEdit) {
      setCars(p => p.map(c => c._id === saved._id ? saved : c));
      toast.success('Vehicle updated');
    } else {
      setCars(p => [saved, ...p]);
      toast.success('Vehicle added');
    }
    setModal(null);
  };

  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await deleteCar(selected._id);
      setCars(p => p.filter(c => c._id !== selected._id));
      toast.success('Vehicle deleted');
      setModal(null);
    } catch (e) {
      toast.error(e.response?.data?.message || 'Delete failed');
    } finally { setDeleteLoading(false); }
  };

  return (
    <div className="cars-page">
      {/* Toolbar */}
      <div className="page-toolbar">
        <div className="page-toolbar__filters">
          <div className="search-wrap">
            <svg className="search-icon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input className="form-input search-input" placeholder="Search vehicles..." value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
          <select className="form-input filter-select" value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}>
            <option value="">All Statuses</option>
            {STATUSES.map(s=><option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
          </select>
          <select className="form-input filter-select" value={categoryFilter} onChange={e=>setCategoryFilter(e.target.value)}>
            <option value="">All Categories</option>
            {CAR_CATEGORIES.map(c=><option key={c}>{c}</option>)}
          </select>
        </div>
        <button className="btn btn-primary" onClick={() => { setSelected(null); setModal('add'); }}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add Vehicle
        </button>
      </div>

      {/* Cars grid */}
      {loading ? (
        <div className="cars-grid">
          {[...Array(8)].map((_, i) => <div key={i} className="skeleton car-skeleton" />)}
        </div>
      ) : cars.length === 0 ? (
        <div className="empty-state">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--text-disabled)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 17H3a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v10a2 2 0 0 1-2 2h-1"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>
          </svg>
          <p>No vehicles found</p>
          <button className="btn btn-primary btn-sm" onClick={() => setModal('add')}>Add First Vehicle</button>
        </div>
      ) : (
        <div className="cars-grid">
          {cars.map(car => (
            <div key={car._id} className="car-card">
              <div className="car-card__header" style={{ background: `linear-gradient(135deg, ${carColorMap[car.category] || '#333'}22, ${carColorMap[car.category] || '#333'}08)` }}>
                <div className="car-card__category-dot" style={{ background: carColorMap[car.category] || '#333' }} />
                <span className={`badge badge-${car.status}`}>{car.status}</span>
                <div className="car-card__icon">
                  <svg width="60" height="40" viewBox="0 0 100 60" fill="none">
                    <path d="M15 40 L20 25 Q22 18 32 15 L60 13 Q72 12 80 22 L88 32 Q95 34 96 40 L96 45 Q96 48 93 48 L85 48 Q83 52 80 55 Q75 60 68 55 Q65 52 63 48 L37 48 Q35 52 32 55 Q27 60 20 55 Q17 52 15 48 L7 48 Q4 48 4 44 L4 40 Z" fill={`${carColorMap[car.category] || '#555'}40`} stroke={carColorMap[car.category] || '#555'} strokeWidth="2"/>
                    <circle cx="23" cy="52" r="5" fill={carColorMap[car.category] || '#555'} opacity="0.8"/>
                    <circle cx="72" cy="52" r="5" fill={carColorMap[car.category] || '#555'} opacity="0.8"/>
                    <path d="M35 15 L42 28 L70 28 L65 15 Z" fill="rgba(255,255,255,0.15)"/>
                  </svg>
                </div>
              </div>
              <div className="car-card__body">
                <h4 className="car-card__name">{car.brand} {car.model}</h4>
                <p className="car-card__plate">{car.licensePlate}</p>
                <div className="car-card__specs">
                  <span>{car.year}</span>
                  <span>•</span>
                  <span>{car.transmission}</span>
                  <span>•</span>
                  <span>{car.fuel}</span>
                  <span>•</span>
                  <span>{car.seats} seats</span>
                </div>
                <div className="car-card__footer">
                  <div className="car-card__rate">
                    <span className="car-card__rate-value">${car.dailyRate}</span>
                    <span className="car-card__rate-unit">/day</span>
                  </div>
                  <div className="car-card__actions">
                    <button className="btn btn-ghost btn-sm" onClick={() => { setSelected(car); setModal('edit'); }}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    </button>
                    <button className="btn btn-ghost btn-sm" style={{ color: 'var(--accent-primary)' }} onClick={() => { setSelected(car); setModal('delete'); }}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {pagination.pages > 1 && (
        <div className="pagination">
          {[...Array(pagination.pages)].map((_, i) => (
            <button key={i} className={`pagination__btn ${pagination.page === i+1 ? 'pagination__btn--active' : ''}`} onClick={() => fetchCars(i+1)}>{i+1}</button>
          ))}
        </div>
      )}

      {(modal === 'add' || modal === 'edit') && (
        <CarModal car={modal === 'edit' ? selected : null} onClose={() => setModal(null)} onSave={handleSave} />
      )}
      {modal === 'delete' && selected && (
        <DeleteModal car={selected} onClose={() => setModal(null)} onConfirm={handleDelete} loading={deleteLoading} />
      )}
    </div>
  );
}
