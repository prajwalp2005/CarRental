import React, { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import { format } from 'date-fns';
import { getBookings, createBooking, updateBooking, deleteBooking, getCars, getCustomers } from '../utils/api';
import './BookingsPage.css';

const STATUSES = ['pending','confirmed','active','completed','cancelled'];
const PAYMENT_METHODS = ['cash','card','bank_transfer','online'];
const emptyForm = { customer:'', car:'', startDate:'', endDate:'', pickupLocation:'Main Branch', returnLocation:'Main Branch', dailyRate:'', discount:0, additionalCharges:0, notes:'', paymentMethod:'card', status:'pending' };

function BookingModal({ booking, onClose, onSave }) {
  const [form, setForm] = useState(booking ? {
    ...booking,
    customer: booking.customer?._id || booking.customer,
    car: booking.car?._id || booking.car,
    startDate: booking.startDate ? format(new Date(booking.startDate), 'yyyy-MM-dd') : '',
    endDate: booking.endDate ? format(new Date(booking.endDate), 'yyyy-MM-dd') : '',
  } : emptyForm);
  const [cars, setCars] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(false);
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  useEffect(() => {
    Promise.all([
      getCars({ limit: 100, status: booking ? '' : 'available' }),
      getCustomers({ limit: 100 })
    ]).then(([c, cu]) => {
      setCars(c.data.data);
      setCustomers(cu.data.data);
    });
  }, [booking]);

  // Auto-fill daily rate when car selected
  const handleCarChange = (carId) => {
    set('car', carId);
    const car = cars.find(c => c._id === carId);
    if (car) set('dailyRate', car.dailyRate);
  };

  const calcTotal = () => {
    if (!form.startDate || !form.endDate || !form.dailyRate) return { days: 0, subtotal: 0, taxes: 0, total: 0 };
    const days = Math.max(1, Math.ceil((new Date(form.endDate) - new Date(form.startDate)) / 86400000));
    const subtotal = days * parseFloat(form.dailyRate || 0);
    const taxes = subtotal * 0.1;
    const total = subtotal + taxes + parseFloat(form.additionalCharges || 0) - parseFloat(form.discount || 0);
    return { days, subtotal, taxes, total };
  };

  const { days, subtotal, taxes, total } = calcTotal();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = { ...form, totalDays: days, subtotal, taxes, totalAmount: total };
      let saved;
      if (booking?._id) { const r = await updateBooking(booking._id, payload); saved = r.data.data; }
      else { const r = await createBooking(payload); saved = r.data.data; }
      onSave(saved, !!booking?._id);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save booking');
    } finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 680 }}>
        <div className="modal-header">
          <h3>{booking ? `Edit Booking — ${booking.bookingNumber}` : 'New Booking'}</h3>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-grid">
              <div className="form-group form-group--full">
                <label className="form-label">Customer *</label>
                <select className="form-input" value={form.customer} onChange={e=>set('customer',e.target.value)} required>
                  <option value="">Select customer...</option>
                  {customers.map(c => <option key={c._id} value={c._id}>{c.firstName} {c.lastName} — {c.email}</option>)}
                </select>
              </div>
              <div className="form-group form-group--full">
                <label className="form-label">Vehicle *</label>
                <select className="form-input" value={form.car} onChange={e=>handleCarChange(e.target.value)} required>
                  <option value="">Select vehicle...</option>
                  {cars.map(c => <option key={c._id} value={c._id}>{c.brand} {c.model} ({c.licensePlate}) — ${c.dailyRate}/day</option>)}
                </select>
              </div>
              <div className="form-group"><label className="form-label">Start Date *</label><input className="form-input" type="date" value={form.startDate} onChange={e=>set('startDate',e.target.value)} required /></div>
              <div className="form-group"><label className="form-label">End Date *</label><input className="form-input" type="date" value={form.endDate} onChange={e=>set('endDate',e.target.value)} required /></div>
              <div className="form-group"><label className="form-label">Pickup Location</label><input className="form-input" value={form.pickupLocation} onChange={e=>set('pickupLocation',e.target.value)} /></div>
              <div className="form-group"><label className="form-label">Return Location</label><input className="form-input" value={form.returnLocation} onChange={e=>set('returnLocation',e.target.value)} /></div>
              <div className="form-group"><label className="form-label">Daily Rate ($)</label><input className="form-input" type="number" value={form.dailyRate} onChange={e=>set('dailyRate',e.target.value)} required min="0" /></div>
              <div className="form-group"><label className="form-label">Discount ($)</label><input className="form-input" type="number" value={form.discount} onChange={e=>set('discount',e.target.value)} min="0" /></div>
              <div className="form-group"><label className="form-label">Extra Charges ($)</label><input className="form-input" type="number" value={form.additionalCharges} onChange={e=>set('additionalCharges',e.target.value)} min="0" /></div>
              <div className="form-group"><label className="form-label">Payment Method</label><select className="form-input" value={form.paymentMethod} onChange={e=>set('paymentMethod',e.target.value)}>{PAYMENT_METHODS.map(m=><option key={m}>{m}</option>)}</select></div>
              {booking && (
                <div className="form-group"><label className="form-label">Status</label>
                  <select className="form-input" value={form.status} onChange={e=>set('status',e.target.value)}>
                    {STATUSES.map(s=><option key={s}>{s}</option>)}
                  </select>
                </div>
              )}
              <div className="form-group form-group--full"><label className="form-label">Notes</label><textarea className="form-input" rows={2} value={form.notes} onChange={e=>set('notes',e.target.value)} style={{ resize:'vertical' }} /></div>
            </div>

            {/* Price summary */}
            {form.startDate && form.endDate && form.dailyRate && (
              <div className="booking-summary">
                <h4>Booking Summary</h4>
                <div className="booking-summary__rows">
                  <div className="booking-summary__row"><span>{days} day{days !== 1 ? 's' : ''} × ${parseFloat(form.dailyRate).toFixed(2)}</span><span>${subtotal.toFixed(2)}</span></div>
                  <div className="booking-summary__row"><span>Tax (10%)</span><span>${taxes.toFixed(2)}</span></div>
                  {parseFloat(form.additionalCharges) > 0 && <div className="booking-summary__row"><span>Extra Charges</span><span>+${parseFloat(form.additionalCharges).toFixed(2)}</span></div>}
                  {parseFloat(form.discount) > 0 && <div className="booking-summary__row" style={{ color:'#00D4AA' }}><span>Discount</span><span>-${parseFloat(form.discount).toFixed(2)}</span></div>}
                  <div className="booking-summary__total"><span>Total</span><span>${total.toFixed(2)}</span></div>
                </div>
              </div>
            )}
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Saving...' : (booking ? 'Update Booking' : 'Create Booking')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function BookingsPage() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [modal, setModal] = useState(null);
  const [selected, setSelected] = useState(null);
  const [pagination, setPagination] = useState({ page: 1, pages: 1, total: 0 });

  const fetchBookings = useCallback(async (page = 1) => {
    setLoading(true);
    try {
      const params = { page, limit: 10 };
      if (statusFilter) params.status = statusFilter;
      const res = await getBookings(params);
      setBookings(res.data.data);
      setPagination(res.data.pagination);
    } catch { toast.error('Failed to load bookings'); }
    finally { setLoading(false); }
  }, [statusFilter]);

  useEffect(() => { fetchBookings(); }, [fetchBookings]);

  const handleSave = (saved, isEdit) => {
    if (isEdit) { setBookings(p => p.map(b => b._id === saved._id ? saved : b)); toast.success('Booking updated'); }
    else { setBookings(p => [saved, ...p]); toast.success('Booking created'); }
    setModal(null);
  };

  const handleStatusChange = async (id, newStatus) => {
    try {
      const res = await updateBooking(id, { status: newStatus });
      setBookings(p => p.map(b => b._id === id ? res.data.data : b));
      toast.success(`Status updated to ${newStatus}`);
    } catch (e) { toast.error(e.response?.data?.message || 'Update failed'); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this booking?')) return;
    try {
      await deleteBooking(id);
      setBookings(p => p.filter(b => b._id !== id));
      toast.success('Booking deleted');
    } catch (e) { toast.error(e.response?.data?.message || 'Delete failed'); }
  };

  const statusOptions = { pending: ['confirmed','cancelled'], confirmed: ['active','cancelled'], active: ['completed'], completed: [], cancelled: [] };

  return (
    <div className="bookings-page">
      <div className="page-toolbar">
        <div className="page-toolbar__filters">
          {['', ...STATUSES].map(s => (
            <button key={s} className={`filter-chip ${statusFilter === s ? 'filter-chip--active' : ''}`} onClick={() => setStatusFilter(s)}>
              {s ? s.charAt(0).toUpperCase() + s.slice(1) : 'All'}
              {s === '' && <span className="filter-chip__count">{pagination.total}</span>}
            </button>
          ))}
        </div>
        <button className="btn btn-primary" onClick={() => { setSelected(null); setModal('create'); }}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          New Booking
        </button>
      </div>

      <div className="card">
        {loading ? (
          <div style={{ padding: 20 }}>{[...Array(5)].map((_, i) => <div key={i} className="skeleton" style={{ height: 52, marginBottom: 8, borderRadius: 8 }} />)}</div>
        ) : (
          <div className="table-container">
            <table className="data-table">
              <thead><tr><th>Booking #</th><th>Customer</th><th>Vehicle</th><th>Period</th><th>Total</th><th>Payment</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                {bookings.length === 0 ? (
                  <tr><td colSpan={8}><div className="empty-state" style={{ padding: '40px 0' }}>No bookings found</div></td></tr>
                ) : bookings.map(b => (
                  <tr key={b._id}>
                    <td><span className="booking-number">{b.bookingNumber}</span></td>
                    <td>
                      <div className="table-customer">
                        <div className="table-avatar">{b.customer?.firstName?.charAt(0)}{b.customer?.lastName?.charAt(0)}</div>
                        <div>
                          <div style={{ fontWeight: 500 }}>{b.customer?.firstName} {b.customer?.lastName}</div>
                          <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{b.customer?.phone}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div style={{ fontWeight: 500 }}>{b.car?.brand} {b.car?.model}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{b.car?.licensePlate}</div>
                    </td>
                    <td style={{ fontSize: 13 }}>
                      <div>{format(new Date(b.startDate), 'MMM d, yyyy')}</div>
                      <div style={{ color: 'var(--text-tertiary)' }}>{format(new Date(b.endDate), 'MMM d, yyyy')}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: 700, color: '#00D4AA', fontSize: 15 }}>${b.totalAmount?.toLocaleString()}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{b.totalDays} days</div>
                    </td>
                    <td><span className={`badge badge-${b.paymentStatus}`}>{b.paymentStatus}</span></td>
                    <td>
                      {statusOptions[b.status]?.length > 0 ? (
                        <select className="form-input" style={{ padding: '4px 8px', fontSize: 12, width: 'auto' }} value={b.status} onChange={e => handleStatusChange(b._id, e.target.value)}>
                          <option value={b.status}>{b.status}</option>
                          {statusOptions[b.status].map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      ) : (
                        <span className={`badge badge-${b.status}`}>{b.status}</span>
                      )}
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-ghost btn-sm" onClick={() => { setSelected(b); setModal('edit'); }}>
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                        {b.status === 'pending' && (
                          <button className="btn btn-ghost btn-sm" style={{ color: 'var(--accent-primary)' }} onClick={() => handleDelete(b._id)}>
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {pagination.pages > 1 && (
        <div className="pagination">
          {[...Array(pagination.pages)].map((_, i) => (
            <button key={i} className={`pagination__btn ${pagination.page === i+1 ? 'pagination__btn--active' : ''}`} onClick={() => fetchBookings(i+1)}>{i+1}</button>
          ))}
        </div>
      )}

      {(modal === 'create' || modal === 'edit') && (
        <BookingModal booking={modal === 'edit' ? selected : null} onClose={() => setModal(null)} onSave={handleSave} />
      )}
    </div>
  );
}
