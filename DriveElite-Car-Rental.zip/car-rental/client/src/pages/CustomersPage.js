import React, { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import { format } from 'date-fns';
import { getCustomers, createCustomer, updateCustomer, deleteCustomer } from '../utils/api';
import './CustomersPage.css';

const emptyForm = {
  firstName:'', lastName:'', email:'', phone:'', driverLicense:'',
  licenseExpiry:'', dateOfBirth:'', status:'active', notes:'',
  address:{ street:'', city:'', state:'', zipCode:'', country:'USA' }
};

function CustomerModal({ customer, onClose, onSave }) {
  const [form, setForm] = useState(customer ? {
    ...customer,
    licenseExpiry: customer.licenseExpiry ? format(new Date(customer.licenseExpiry), 'yyyy-MM-dd') : '',
    dateOfBirth: customer.dateOfBirth ? format(new Date(customer.dateOfBirth), 'yyyy-MM-dd') : '',
    address: customer.address || emptyForm.address,
  } : emptyForm);
  const [loading, setLoading] = useState(false);
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const setAddr = (k, v) => setForm(p => ({ ...p, address: { ...p.address, [k]: v } }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      let saved;
      if (customer?._id) { const r = await updateCustomer(customer._id, form); saved = r.data.data; }
      else { const r = await createCustomer(form); saved = r.data.data; }
      onSave(saved, !!customer?._id);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save customer');
    } finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 640 }}>
        <div className="modal-header">
          <h3>{customer ? 'Edit Customer' : 'Add New Customer'}</h3>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="modal-section-title">Personal Information</div>
            <div className="form-grid">
              <div className="form-group"><label className="form-label">First Name *</label><input className="form-input" value={form.firstName} onChange={e=>set('firstName',e.target.value)} required /></div>
              <div className="form-group"><label className="form-label">Last Name *</label><input className="form-input" value={form.lastName} onChange={e=>set('lastName',e.target.value)} required /></div>
              <div className="form-group"><label className="form-label">Email *</label><input className="form-input" type="email" value={form.email} onChange={e=>set('email',e.target.value)} required /></div>
              <div className="form-group"><label className="form-label">Phone *</label><input className="form-input" value={form.phone} onChange={e=>set('phone',e.target.value)} required /></div>
              <div className="form-group"><label className="form-label">Date of Birth</label><input className="form-input" type="date" value={form.dateOfBirth} onChange={e=>set('dateOfBirth',e.target.value)} /></div>
              <div className="form-group"><label className="form-label">Status</label><select className="form-input" value={form.status} onChange={e=>set('status',e.target.value)}><option value="active">Active</option><option value="suspended">Suspended</option><option value="blacklisted">Blacklisted</option></select></div>
            </div>

            <div className="modal-section-title" style={{ marginTop: 20 }}>Driver License</div>
            <div className="form-grid">
              <div className="form-group"><label className="form-label">License Number *</label><input className="form-input" value={form.driverLicense} onChange={e=>set('driverLicense',e.target.value)} required /></div>
              <div className="form-group"><label className="form-label">License Expiry *</label><input className="form-input" type="date" value={form.licenseExpiry} onChange={e=>set('licenseExpiry',e.target.value)} required /></div>
            </div>

            <div className="modal-section-title" style={{ marginTop: 20 }}>Address</div>
            <div className="form-grid">
              <div className="form-group form-group--full"><label className="form-label">Street</label><input className="form-input" value={form.address.street} onChange={e=>setAddr('street',e.target.value)} /></div>
              <div className="form-group"><label className="form-label">City</label><input className="form-input" value={form.address.city} onChange={e=>setAddr('city',e.target.value)} /></div>
              <div className="form-group"><label className="form-label">State</label><input className="form-input" value={form.address.state} onChange={e=>setAddr('state',e.target.value)} /></div>
              <div className="form-group"><label className="form-label">ZIP Code</label><input className="form-input" value={form.address.zipCode} onChange={e=>setAddr('zipCode',e.target.value)} /></div>
              <div className="form-group"><label className="form-label">Country</label><input className="form-input" value={form.address.country} onChange={e=>setAddr('country',e.target.value)} /></div>
            </div>

            <div className="form-group" style={{ marginTop: 16 }}>
              <label className="form-label">Notes</label>
              <textarea className="form-input" rows={2} value={form.notes} onChange={e=>set('notes',e.target.value)} style={{ resize:'vertical' }} />
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Saving...' : (customer ? 'Update Customer' : 'Add Customer')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState(null);
  const [selected, setSelected] = useState(null);
  const [pagination, setPagination] = useState({ page: 1, pages: 1, total: 0 });

  const fetchCustomers = useCallback(async (page = 1) => {
    setLoading(true);
    try {
      const params = { page, limit: 10 };
      if (search) params.search = search;
      const res = await getCustomers(params);
      setCustomers(res.data.data);
      setPagination(res.data.pagination);
    } catch { toast.error('Failed to load customers'); }
    finally { setLoading(false); }
  }, [search]);

  useEffect(() => { fetchCustomers(); }, [fetchCustomers]);

  const handleSave = (saved, isEdit) => {
    if (isEdit) { setCustomers(p => p.map(c => c._id === saved._id ? saved : c)); toast.success('Customer updated'); }
    else { setCustomers(p => [saved, ...p]); toast.success('Customer added'); }
    setModal(null);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this customer?')) return;
    try {
      await deleteCustomer(id);
      setCustomers(p => p.filter(c => c._id !== id));
      toast.success('Customer deleted');
    } catch (e) { toast.error(e.response?.data?.message || 'Delete failed'); }
  };

  const licenseExpired = (expiry) => expiry && new Date(expiry) < new Date();

  return (
    <div className="customers-page">
      <div className="page-toolbar">
        <div className="page-toolbar__filters">
          <div className="search-wrap" style={{ maxWidth: 360, flex: 1 }}>
            <svg className="search-icon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input className="form-input search-input" placeholder="Search by name, email, license..." value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
          <div className="customer-count">
            <span>{pagination.total}</span> customers
          </div>
        </div>
        <button className="btn btn-primary" onClick={() => { setSelected(null); setModal('add'); }}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add Customer
        </button>
      </div>

      <div className="card">
        {loading ? (
          <div style={{ padding: 20 }}>{[...Array(6)].map((_, i) => <div key={i} className="skeleton" style={{ height: 64, marginBottom: 8, borderRadius: 10 }} />)}</div>
        ) : (
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr><th>Customer</th><th>Contact</th><th>Driver License</th><th>Rentals</th><th>Total Spent</th><th>Status</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {customers.length === 0 ? (
                  <tr><td colSpan={7}><div className="empty-state" style={{ padding: '40px 0' }}>No customers found</div></td></tr>
                ) : customers.map(c => (
                  <tr key={c._id}>
                    <td>
                      <div className="table-customer">
                        <div className="table-avatar" style={{ background: `hsl(${(c.firstName.charCodeAt(0) * 15) % 360}, 60%, 40%)` }}>
                          {c.firstName.charAt(0)}{c.lastName.charAt(0)}
                        </div>
                        <div>
                          <div style={{ fontWeight: 600 }}>{c.firstName} {c.lastName}</div>
                          <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>
                            {c.dateOfBirth && `Born ${format(new Date(c.dateOfBirth), 'MMM d, yyyy')}`}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div style={{ fontSize: 13 }}>{c.email}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{c.phone}</div>
                    </td>
                    <td>
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700 }}>{c.driverLicense}</div>
                      <div style={{ fontSize: 11, color: licenseExpired(c.licenseExpiry) ? '#E63946' : 'var(--text-tertiary)' }}>
                        {c.licenseExpiry && `Exp: ${format(new Date(c.licenseExpiry), 'MMM yyyy')}`}
                        {licenseExpired(c.licenseExpiry) && ' ⚠ Expired'}
                      </div>
                    </td>
                    <td style={{ fontWeight: 600, textAlign: 'center' }}>{c.totalRentals}</td>
                    <td style={{ fontWeight: 700, color: '#00D4AA' }}>${c.totalSpent?.toLocaleString()}</td>
                    <td><span className={`badge badge-${c.status}`}>{c.status}</span></td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-ghost btn-sm" onClick={() => { setSelected(c); setModal('edit'); }}>
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                        <button className="btn btn-ghost btn-sm" style={{ color: 'var(--accent-primary)' }} onClick={() => handleDelete(c._id)}>
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {pagination.pages > 1 && (
        <div className="pagination">
          {[...Array(pagination.pages)].map((_, i) => (
            <button key={i} className={`pagination__btn ${pagination.page === i+1 ? 'pagination__btn--active' : ''}`} onClick={() => fetchCustomers(i+1)}>{i+1}</button>
          ))}
        </div>
      )}

      {(modal === 'add' || modal === 'edit') && (
        <CustomerModal customer={modal === 'edit' ? selected : null} onClose={() => setModal(null)} onSave={handleSave} />
      )}
    </div>
  );
}
