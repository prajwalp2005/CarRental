import React, { useEffect, useState } from 'react';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { getDashboardStats, getRevenueChart, getRecentBookings, getCarUtilization } from '../utils/api';
import { format } from 'date-fns';
import './DashboardPage.css';

const StatCard = ({ icon, label, value, sub, trend, color }) => (
  <div className="stat-card" style={{ '--accent': color }}>
    <div className="stat-card__icon" style={{ background: `${color}18`, border: `1px solid ${color}30` }}>
      {icon}
    </div>
    <div className="stat-card__body">
      <p className="stat-card__label">{label}</p>
      <p className="stat-card__value">{value}</p>
      {trend !== undefined && (
        <p className={`stat-card__trend ${trend >= 0 ? 'stat-card__trend--up' : 'stat-card__trend--down'}`}>
          {trend >= 0 ? '↑' : '↓'} {Math.abs(trend)}% this month
        </p>
      )}
      {sub && <p className="stat-card__sub">{sub}</p>}
    </div>
    <div className="stat-card__glow" />
  </div>
);

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="chart-tooltip">
        <p className="chart-tooltip__label">{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color }}>
            {p.name}: {p.name === 'revenue' ? `$${p.value.toLocaleString()}` : p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const statusColors = { available: '#00D4AA', rented: '#E63946', maintenance: '#FFB800', reserved: '#4361EE' };

export default function DashboardPage() {
  const [stats, setStats] = useState(null);
  const [revenue, setRevenue] = useState([]);
  const [recentBookings, setRecentBookings] = useState([]);
  const [utilization, setUtilization] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [s, r, rb, u] = await Promise.all([
          getDashboardStats(), getRevenueChart(), getRecentBookings(), getCarUtilization()
        ]);
        setStats(s.data.data);
        setRevenue(r.data.data);
        setRecentBookings(rb.data.data);
        setUtilization(u.data.data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  if (loading) return (
    <div className="dashboard-loading">
      {[...Array(4)].map((_, i) => <div key={i} className="skeleton" style={{ height: 110, borderRadius: 16, animationDelay: `${i * 0.1}s` }} />)}
    </div>
  );

  return (
    <div className="dashboard">
      {/* Stats row */}
      <div className="dashboard__stats">
        <StatCard
          label="Total Revenue" color="#00D4AA"
          value={`$${(stats?.totalRevenue || 0).toLocaleString()}`}
          trend={stats?.revenueGrowth} icon={
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00D4AA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
            </svg>
          }
        />
        <StatCard
          label="Active Fleet" color="#4361EE"
          value={stats?.totalCars || 0}
          sub={`${stats?.availableCars || 0} available`} icon={
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4361EE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 17H3a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v10a2 2 0 0 1-2 2h-1"/>
              <circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>
            </svg>
          }
        />
        <StatCard
          label="Total Customers" color="#FFB800"
          value={stats?.totalCustomers || 0}
          sub="Registered members" icon={
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#FFB800" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
            </svg>
          }
        />
        <StatCard
          label="Active Bookings" color="#E63946"
          value={stats?.activeBookings || 0}
          sub={`${stats?.rentedCars || 0} cars on road`} icon={
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E63946" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/>
              <line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
            </svg>
          }
        />
      </div>

      {/* Charts row */}
      <div className="dashboard__charts">
        <div className="card dashboard__revenue-chart">
          <div className="card-header">
            <div>
              <h3>Revenue Overview</h3>
              <p>6-month performance</p>
            </div>
            <div className="chart-legend">
              <span style={{ color: '#00D4AA' }}>● Revenue</span>
              <span style={{ color: '#4361EE' }}>● Bookings</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={revenue} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00D4AA" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#00D4AA" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="bookGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4361EE" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#4361EE" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid stroke="rgba(255,255,255,0.04)" strokeDasharray="0" />
              <XAxis dataKey="month" tick={{ fill: 'rgba(240,240,248,0.4)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'rgba(240,240,248,0.4)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v.toLocaleString()}`} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="revenue" stroke="#00D4AA" strokeWidth={2} fill="url(#revGrad)" />
              <Area type="monotone" dataKey="bookings" stroke="#4361EE" strokeWidth={2} fill="url(#bookGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card dashboard__utilization">
          <div className="card-header">
            <div>
              <h3>Fleet by Category</h3>
              <p>Vehicle distribution</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={utilization.map(d => ({ name: d._id, total: d.count, available: d.available, rented: d.rented }))} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="rgba(255,255,255,0.04)" strokeDasharray="0" vertical={false} />
              <XAxis dataKey="name" tick={{ fill: 'rgba(240,240,248,0.4)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'rgba(240,240,248,0.4)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="available" fill="#00D4AA" radius={[4,4,0,0]} opacity={0.85} />
              <Bar dataKey="rented" fill="#E63946" radius={[4,4,0,0]} opacity={0.85} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent bookings */}
      <div className="card dashboard__recent">
        <div className="card-header">
          <div>
            <h3>Recent Bookings</h3>
            <p>Latest rental activity</p>
          </div>
        </div>
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Booking</th><th>Customer</th><th>Vehicle</th>
                <th>Period</th><th>Amount</th><th>Status</th>
              </tr>
            </thead>
            <tbody>
              {recentBookings.map(b => (
                <tr key={b._id}>
                  <td><span className="booking-number">{b.bookingNumber}</span></td>
                  <td>
                    <div className="table-customer">
                      <div className="table-avatar">{b.customer?.firstName?.charAt(0)}{b.customer?.lastName?.charAt(0)}</div>
                      <div>
                        <div style={{ fontWeight: 500 }}>{b.customer?.firstName} {b.customer?.lastName}</div>
                        <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{b.customer?.email}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div style={{ fontWeight: 500 }}>{b.car?.brand} {b.car?.model}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{b.car?.category}</div>
                  </td>
                  <td style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
                    {format(new Date(b.startDate), 'MMM d')} → {format(new Date(b.endDate), 'MMM d, yyyy')}
                  </td>
                  <td><span style={{ fontWeight: 600, color: '#00D4AA' }}>${b.totalAmount?.toLocaleString()}</span></td>
                  <td><span className={`badge badge-${b.status}`}>{b.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
