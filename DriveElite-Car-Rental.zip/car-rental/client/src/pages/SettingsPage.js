import React, { useState } from 'react';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import './SettingsPage.css';

export default function SettingsPage() {
  const { user, updateProfile } = useAuth();
  const [profileForm, setProfileForm] = useState({ name: user?.name || '', email: user?.email || '' });
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [profileLoading, setProfileLoading] = useState(false);
  const [pwLoading, setPwLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');

  const handleProfileSave = async (e) => {
    e.preventDefault();
    setProfileLoading(true);
    try {
      await updateProfile(profileForm);
      toast.success('Profile updated');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally { setProfileLoading(false); }
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    if (pwForm.newPassword !== pwForm.confirmPassword) {
      return toast.error('Passwords do not match');
    }
    if (pwForm.newPassword.length < 6) {
      return toast.error('Password must be at least 6 characters');
    }
    setPwLoading(true);
    try {
      await axios.put('/api/auth/change-password', { currentPassword: pwForm.currentPassword, newPassword: pwForm.newPassword });
      toast.success('Password changed successfully');
      setPwForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to change password');
    } finally { setPwLoading(false); }
  };

  const tabs = [
    { id: 'profile', label: 'Profile' },
    { id: 'security', label: 'Security' },
    { id: 'system', label: 'System Info' },
  ];

  return (
    <div className="settings-page">
      <div className="settings-layout">
        {/* Sidebar tabs */}
        <div className="settings-nav">
          {tabs.map(t => (
            <button key={t.id} className={`settings-nav__item ${activeTab === t.id ? 'settings-nav__item--active' : ''}`} onClick={() => setActiveTab(t.id)}>
              {t.label}
            </button>
          ))}
        </div>

        <div className="settings-content">
          {/* Profile tab */}
          {activeTab === 'profile' && (
            <div className="card settings-card animate-fadeIn">
              <div className="settings-card__header">
                <h3>Profile Information</h3>
                <p>Update your account details and personal information</p>
              </div>
              <div className="settings-card__body">
                <div className="profile-avatar-section">
                  <div className="profile-avatar">{user?.name?.charAt(0).toUpperCase()}</div>
                  <div>
                    <h4>{user?.name}</h4>
                    <p>{user?.role}</p>
                  </div>
                </div>
                <form onSubmit={handleProfileSave}>
                  <div className="form-grid">
                    <div className="form-group">
                      <label className="form-label">Full Name</label>
                      <input className="form-input" value={profileForm.name} onChange={e => setProfileForm(p => ({ ...p, name: e.target.value }))} required />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Email Address</label>
                      <input className="form-input" type="email" value={profileForm.email} onChange={e => setProfileForm(p => ({ ...p, email: e.target.value }))} required />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Role</label>
                      <input className="form-input" value={user?.role || ''} disabled style={{ opacity: 0.5, cursor: 'not-allowed' }} />
                    </div>
                  </div>
                  <button type="submit" className="btn btn-primary" style={{ marginTop: 20 }} disabled={profileLoading}>
                    {profileLoading ? 'Saving...' : 'Save Changes'}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* Security tab */}
          {activeTab === 'security' && (
            <div className="card settings-card animate-fadeIn">
              <div className="settings-card__header">
                <h3>Change Password</h3>
                <p>Keep your account secure with a strong password</p>
              </div>
              <div className="settings-card__body">
                <form onSubmit={handlePasswordChange}>
                  <div className="form-grid" style={{ gridTemplateColumns: '1fr' }}>
                    <div className="form-group">
                      <label className="form-label">Current Password</label>
                      <input className="form-input" type="password" value={pwForm.currentPassword} onChange={e => setPwForm(p => ({ ...p, currentPassword: e.target.value }))} required />
                    </div>
                    <div className="form-group">
                      <label className="form-label">New Password</label>
                      <input className="form-input" type="password" value={pwForm.newPassword} onChange={e => setPwForm(p => ({ ...p, newPassword: e.target.value }))} required minLength={6} />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Confirm New Password</label>
                      <input className="form-input" type="password" value={pwForm.confirmPassword} onChange={e => setPwForm(p => ({ ...p, confirmPassword: e.target.value }))} required />
                    </div>
                  </div>
                  <button type="submit" className="btn btn-primary" style={{ marginTop: 20 }} disabled={pwLoading}>
                    {pwLoading ? 'Changing...' : 'Change Password'}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* System tab */}
          {activeTab === 'system' && (
            <div className="card settings-card animate-fadeIn">
              <div className="settings-card__header">
                <h3>System Information</h3>
                <p>Technical details about the DriveElite platform</p>
              </div>
              <div className="settings-card__body">
                <div className="system-info">
                  {[
                    { label: 'Application', value: 'DriveElite Car Rental Management' },
                    { label: 'Version', value: '1.0.0' },
                    { label: 'Stack', value: 'MERN (MongoDB, Express, React, Node.js)' },
                    { label: 'Frontend', value: 'React 18 + React Router v6' },
                    { label: 'Backend', value: 'Node.js + Express.js' },
                    { label: 'Database', value: 'MongoDB with Mongoose ODM' },
                    { label: 'Authentication', value: 'JWT (JSON Web Tokens)' },
                    { label: 'Charts', value: 'Recharts' },
                    { label: 'Environment', value: process.env.NODE_ENV },
                    { label: 'API URL', value: process.env.REACT_APP_API_URL || 'http://localhost:5000' },
                  ].map(({ label, value }) => (
                    <div key={label} className="system-info__row">
                      <span className="system-info__label">{label}</span>
                      <span className="system-info__value">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
