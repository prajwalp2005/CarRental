import React from 'react';
import { useLocation } from 'react-router-dom';
import './Topbar.css';

const pageTitles = {
  '/': { title: 'Dashboard', sub: 'Welcome back! Here's what's happening today.' },
  '/cars': { title: 'Fleet Management', sub: 'Manage your vehicle inventory' },
  '/bookings': { title: 'Bookings', sub: 'Track all rental reservations' },
  '/customers': { title: 'Customers', sub: 'Manage customer profiles' },
  '/settings': { title: 'Settings', sub: 'Configure your account & preferences' },
};

export default function Topbar({ onMenuClick }) {
  const location = useLocation();
  const page = pageTitles[location.pathname] || { title: 'DriveElite', sub: '' };
  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <header className="topbar">
      <div className="topbar__left">
        <button className="topbar__menu-btn" onClick={onMenuClick}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="3" y1="6" x2="21" y2="6"/>
            <line x1="3" y1="12" x2="21" y2="12"/>
            <line x1="3" y1="18" x2="15" y2="18"/>
          </svg>
        </button>
        <div>
          <h1 className="topbar__title">{page.title}</h1>
          <p className="topbar__sub">{page.sub}</p>
        </div>
      </div>
      <div className="topbar__right">
        <div className="topbar__date">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/>
            <line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
          </svg>
          {dateStr}
        </div>
        <div className="topbar__divider" />
        <div className="topbar__status">
          <span className="topbar__status-dot" />
          Live
        </div>
      </div>
    </header>
  );
}
