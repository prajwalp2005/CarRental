import axios from 'axios';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000',
});

// Request interceptor – attach token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Response interceptor – handle 401
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ── Cars ──────────────────────────────────────────
export const getCars = (params) => api.get('/api/cars', { params });
export const getCar = (id) => api.get(`/api/cars/${id}`);
export const createCar = (data) => api.post('/api/cars', data);
export const updateCar = (id, data) => api.put(`/api/cars/${id}`, data);
export const deleteCar = (id) => api.delete(`/api/cars/${id}`);
export const getCarStats = () => api.get('/api/cars/stats/overview');

// ── Bookings ─────────────────────────────────────
export const getBookings = (params) => api.get('/api/bookings', { params });
export const getBooking = (id) => api.get(`/api/bookings/${id}`);
export const createBooking = (data) => api.post('/api/bookings', data);
export const updateBooking = (id, data) => api.put(`/api/bookings/${id}`, data);
export const deleteBooking = (id) => api.delete(`/api/bookings/${id}`);

// ── Customers ─────────────────────────────────────
export const getCustomers = (params) => api.get('/api/customers', { params });
export const getCustomer = (id) => api.get(`/api/customers/${id}`);
export const createCustomer = (data) => api.post('/api/customers', data);
export const updateCustomer = (id, data) => api.put(`/api/customers/${id}`, data);
export const deleteCustomer = (id) => api.delete(`/api/customers/${id}`);

// ── Dashboard ────────────────────────────────────
export const getDashboardStats = () => api.get('/api/dashboard/stats');
export const getRevenueChart = () => api.get('/api/dashboard/revenue-chart');
export const getRecentBookings = () => api.get('/api/dashboard/recent-bookings');
export const getCarUtilization = () => api.get('/api/dashboard/car-utilization');

// ── Auth ─────────────────────────────────────────
export const authLogin = (data) => api.post('/api/auth/login', data);
export const authRegister = (data) => api.post('/api/auth/register', data);
export const authMe = () => api.get('/api/auth/me');
export const changePassword = (data) => api.put('/api/auth/change-password', data);

export default api;
