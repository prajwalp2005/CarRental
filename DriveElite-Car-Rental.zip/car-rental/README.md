# 🚗 DriveElite — Car Rental Management System

A full-stack **MERN** (MongoDB, Express, React, Node.js) car rental management system with a premium dark UI, real-time analytics, and complete CRUD for fleet, bookings, and customers.

---

## ✨ Features

### Frontend
- **Premium dark UI** with animated gradients, glassmorphism cards, and micro-interactions
- **Dashboard** with live KPIs, revenue area charts, fleet utilization bar charts
- **Fleet Management** — card-based grid with SVG car illustrations, filter by status/category
- **Bookings** — full lifecycle management (pending → confirmed → active → completed), inline status updates, auto price calculator
- **Customer Management** — license expiry warnings, spending history, search
- **Settings** — profile editing, password change, system info
- **Authentication** — JWT-based login with protected routes

### Backend
- **RESTful API** with full CRUD for cars, bookings, customers
- **JWT Authentication** with role-based access (admin, manager, staff)
- **Dashboard analytics** — revenue aggregation, monthly trends, fleet utilization
- **Auto booking number** generation (BK000001, BK000002…)
- **Business logic** — car status auto-updates when booking status changes, revenue tracking
- **Seed script** — 10 cars, 6 customers, 5 bookings pre-loaded

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, React Router v6, Recharts, Axios |
| Backend | Node.js, Express.js |
| Database | MongoDB, Mongoose ODM |
| Auth | JSON Web Tokens (JWT), bcryptjs |
| Styling | Pure CSS with CSS Variables |
| Notifications | react-hot-toast |

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** v18+ ([nodejs.org](https://nodejs.org))
- **MongoDB** running locally OR a [MongoDB Atlas](https://www.mongodb.com/atlas) connection string

### 1. Install Dependencies

```bash
# Install server dependencies
cd server
npm install

# Install client dependencies
cd ../client
npm install
```

### 2. Configure Environment

The server `.env` file is already included with default settings:

```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/car_rental_db
JWT_SECRET=your_super_secret_jwt_key_change_in_production_2024
JWT_EXPIRE=7d
CLIENT_URL=http://localhost:3000
```

> 🔑 **For MongoDB Atlas**, replace `MONGODB_URI` with your Atlas connection string.

### 3. Seed the Database

```bash
cd server
npm run seed
```

This creates:
- 2 users (admin + manager)
- 10 cars across all categories
- 6 customers
- 5 sample bookings

### 4. Start the Application

**Terminal 1 — Backend:**
```bash
cd server
npm run dev
```
Server starts at `http://localhost:5000`

**Terminal 2 — Frontend:**
```bash
cd client
npm start
```
App opens at `http://localhost:3000`

---

## 🔐 Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@carrental.com | Admin123! |
| Manager | manager@carrental.com | Manager123! |

---

## 📁 Project Structure

```
car-rental/
├── server/                     # Express + Node.js backend
│   ├── config/
│   │   └── seed.js             # Database seed script
│   ├── middleware/
│   │   └── auth.js             # JWT auth middleware
│   ├── models/
│   │   ├── User.js             # User schema
│   │   ├── Car.js              # Car/vehicle schema
│   │   ├── Customer.js         # Customer schema
│   │   └── Booking.js          # Booking schema
│   ├── routes/
│   │   ├── auth.js             # Authentication routes
│   │   ├── cars.js             # Fleet CRUD routes
│   │   ├── bookings.js         # Booking CRUD routes
│   │   ├── customers.js        # Customer CRUD routes
│   │   └── dashboard.js        # Analytics routes
│   ├── .env                    # Environment variables
│   ├── index.js                # App entry point
│   └── package.json
│
├── client/                     # React frontend
│   ├── public/
│   │   └── index.html
│   └── src/
│       ├── components/
│       │   └── common/
│       │       ├── Layout.js   # App shell
│       │       ├── Sidebar.js  # Navigation sidebar
│       │       └── Topbar.js   # Top header bar
│       ├── context/
│       │   └── AuthContext.js  # Global auth state
│       ├── pages/
│       │   ├── LoginPage.js    # Auth page
│       │   ├── DashboardPage.js
│       │   ├── CarsPage.js
│       │   ├── BookingsPage.js
│       │   ├── CustomersPage.js
│       │   └── SettingsPage.js
│       ├── utils/
│       │   └── api.js          # Axios API client
│       ├── App.js              # Router + providers
│       ├── index.js            # React entry
│       └── index.css           # Global design system
│
├── package.json                # Root scripts
└── README.md
```

---

## 🔌 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/register` | Register |
| GET | `/api/auth/me` | Get current user |
| PUT | `/api/auth/profile` | Update profile |
| PUT | `/api/auth/change-password` | Change password |

### Cars
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/cars` | List cars (filter, paginate, search) |
| GET | `/api/cars/:id` | Get car by ID |
| POST | `/api/cars` | Create car |
| PUT | `/api/cars/:id` | Update car |
| DELETE | `/api/cars/:id` | Delete car |
| GET | `/api/cars/stats/overview` | Fleet statistics |

### Bookings
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/bookings` | List bookings |
| GET | `/api/bookings/:id` | Get booking |
| POST | `/api/bookings` | Create booking |
| PUT | `/api/bookings/:id` | Update booking / change status |
| DELETE | `/api/bookings/:id` | Delete booking |

### Customers
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/customers` | List customers |
| GET | `/api/customers/:id` | Get customer + recent bookings |
| POST | `/api/customers` | Create customer |
| PUT | `/api/customers/:id` | Update customer |
| DELETE | `/api/customers/:id` | Delete customer |

### Dashboard
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/dashboard/stats` | KPI stats |
| GET | `/api/dashboard/revenue-chart` | 6-month revenue data |
| GET | `/api/dashboard/recent-bookings` | Latest 8 bookings |
| GET | `/api/dashboard/car-utilization` | Fleet by category |

---

## 🎨 Design System

The app uses a **premium dark theme** with CSS custom properties:

- **Colors**: Deep navy base (`#08080E`), crimson accent (`#E63946`), teal success (`#00D4AA`)
- **Typography**: Syne (display/headings) + DM Sans (body)
- **Animations**: Fade-in, scale-in, float blobs, pulsing status dots
- **Components**: Cards with gradient overlays, glassmorphism modals, shimmer skeletons

---

## 🔧 Configuration

### Using MongoDB Atlas (Cloud)
1. Create a free cluster at [mongodb.com/atlas](https://www.mongodb.com/atlas)
2. Get your connection string
3. Update `server/.env`:
```
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/car_rental_db
```

### Production Build
```bash
cd client
npm run build
```
Serve the `build/` folder with any static file server or configure Express to serve it.

---

## 📝 License

MIT — Free for personal and commercial use.
