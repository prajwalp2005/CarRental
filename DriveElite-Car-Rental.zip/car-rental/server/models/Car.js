const mongoose = require('mongoose');

const carSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Car name is required'],
    trim: true
  },
  brand: {
    type: String,
    required: [true, 'Brand is required'],
    trim: true
  },
  model: {
    type: String,
    required: [true, 'Model is required'],
    trim: true
  },
  year: {
    type: Number,
    required: [true, 'Year is required'],
    min: 1990,
    max: new Date().getFullYear() + 1
  },
  category: {
    type: String,
    enum: ['Sedan', 'SUV', 'Sports', 'Luxury', 'Electric', 'Van', 'Truck', 'Convertible'],
    required: [true, 'Category is required']
  },
  licensePlate: {
    type: String,
    required: [true, 'License plate is required'],
    unique: true,
    uppercase: true,
    trim: true
  },
  dailyRate: {
    type: Number,
    required: [true, 'Daily rate is required'],
    min: [0, 'Daily rate cannot be negative']
  },
  status: {
    type: String,
    enum: ['available', 'rented', 'maintenance', 'reserved'],
    default: 'available'
  },
  color: {
    type: String,
    required: [true, 'Color is required']
  },
  seats: {
    type: Number,
    required: true,
    min: 1,
    max: 20
  },
  transmission: {
    type: String,
    enum: ['Automatic', 'Manual'],
    required: true
  },
  fuel: {
    type: String,
    enum: ['Gasoline', 'Diesel', 'Electric', 'Hybrid'],
    required: true
  },
  mileage: {
    type: Number,
    default: 0,
    min: 0
  },
  image: {
    type: String,
    default: ''
  },
  features: [{
    type: String
  }],
  description: {
    type: String,
    maxlength: [500, 'Description cannot exceed 500 characters']
  },
  location: {
    type: String,
    default: 'Main Branch'
  },
  totalEarnings: {
    type: Number,
    default: 0
  },
  totalRentals: {
    type: Number,
    default: 0
  }
}, { timestamps: true });

module.exports = mongoose.model('Car', carSchema);
