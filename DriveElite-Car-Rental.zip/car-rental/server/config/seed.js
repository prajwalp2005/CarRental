const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '../.env') });

const User = require('../models/User');
const Car = require('../models/Car');
const Customer = require('../models/Customer');
const Booking = require('../models/Booking');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/car_rental_db';

const cars = [
  { name: 'Tesla Model S', brand: 'Tesla', model: 'Model S', year: 2023, category: 'Electric', licensePlate: 'EL-001-23', dailyRate: 150, color: 'Midnight Silver', seats: 5, transmission: 'Automatic', fuel: 'Electric', mileage: 12000, features: ['Autopilot', 'Premium Sound', 'Glass Roof', 'Fast Charging'], status: 'available' },
  { name: 'BMW M5', brand: 'BMW', model: 'M5', year: 2023, category: 'Luxury', licensePlate: 'BM-002-23', dailyRate: 200, color: 'Alpine White', seats: 5, transmission: 'Automatic', fuel: 'Gasoline', mileage: 8000, features: ['Sport Mode', 'Heated Seats', 'Panoramic Roof', 'Premium Audio'], status: 'available' },
  { name: 'Mercedes-Benz GLE', brand: 'Mercedes-Benz', model: 'GLE 450', year: 2022, category: 'SUV', licensePlate: 'MB-003-22', dailyRate: 180, color: 'Obsidian Black', seats: 7, transmission: 'Automatic', fuel: 'Hybrid', mileage: 25000, features: ['4MATIC', 'MBUX System', 'Burmester Sound', 'Air Suspension'], status: 'rented' },
  { name: 'Porsche 911 GT3', brand: 'Porsche', model: '911 GT3', year: 2023, category: 'Sports', licensePlate: 'PO-004-23', dailyRate: 350, color: 'Guards Red', seats: 2, transmission: 'Manual', fuel: 'Gasoline', mileage: 3500, features: ['PDK', 'Sport Chrono', 'Carbon Ceramic Brakes', 'Roll Cage'], status: 'available' },
  { name: 'Range Rover Sport', brand: 'Land Rover', model: 'Range Rover Sport', year: 2023, category: 'SUV', licensePlate: 'LR-005-23', dailyRate: 220, color: 'Santorini Black', seats: 5, transmission: 'Automatic', fuel: 'Hybrid', mileage: 15000, features: ['Terrain Response', 'Pivi Pro', 'Meridian Sound', 'Air Suspension'], status: 'available' },
  { name: 'Audi RS6 Avant', brand: 'Audi', model: 'RS6 Avant', year: 2022, category: 'Luxury', licensePlate: 'AU-006-22', dailyRate: 190, color: 'Nardo Grey', seats: 5, transmission: 'Automatic', fuel: 'Gasoline', mileage: 18000, features: ['Quattro AWD', 'Bang & Olufsen', 'Dynamic Ride', 'Night Vision'], status: 'maintenance' },
  { name: 'Ferrari F8 Tributo', brand: 'Ferrari', model: 'F8 Tributo', year: 2022, category: 'Sports', licensePlate: 'FE-007-22', dailyRate: 500, color: 'Rosso Corsa', seats: 2, transmission: 'Automatic', fuel: 'Gasoline', mileage: 5000, features: ['SSC', 'Carbon Fiber', 'Manettino', 'Ferrari Telemetry'], status: 'available' },
  { name: 'Toyota Camry', brand: 'Toyota', model: 'Camry SE', year: 2023, category: 'Sedan', licensePlate: 'TO-008-23', dailyRate: 75, color: 'Midnight Black', seats: 5, transmission: 'Automatic', fuel: 'Hybrid', mileage: 22000, features: ['Apple CarPlay', 'Safety Sense', 'Wireless Charging', 'Sunroof'], status: 'available' },
  { name: 'Ford Mustang GT', brand: 'Ford', model: 'Mustang GT', year: 2023, category: 'Sports', licensePlate: 'FO-009-23', dailyRate: 120, color: 'Velocity Blue', seats: 4, transmission: 'Manual', fuel: 'Gasoline', mileage: 9500, features: ['V8 Engine', 'MagneRide', 'B&O Sound', 'Active Exhaust'], status: 'reserved' },
  { name: 'Rivian R1T', brand: 'Rivian', model: 'R1T Adventure', year: 2023, category: 'Truck', licensePlate: 'RI-010-23', dailyRate: 175, color: 'Forest Green', seats: 5, transmission: 'Automatic', fuel: 'Electric', mileage: 7000, features: ['Quad Motor', 'Camp Mode', 'Air Compressor', 'Gear Tunnel'], status: 'available' }
];

const customers = [
  { firstName: 'James', lastName: 'Carter', email: 'james.carter@email.com', phone: '+1-555-0101', driverLicense: 'DL-CA-123456', licenseExpiry: new Date('2026-08-15'), dateOfBirth: new Date('1988-03-22'), address: { street: '123 Oak Street', city: 'Los Angeles', state: 'CA', zipCode: '90001' }, status: 'active', totalRentals: 12, totalSpent: 4200 },
  { firstName: 'Sophia', lastName: 'Williams', email: 'sophia.w@email.com', phone: '+1-555-0102', driverLicense: 'DL-NY-789012', licenseExpiry: new Date('2025-11-30'), dateOfBirth: new Date('1992-07-14'), address: { street: '456 Park Ave', city: 'New York', state: 'NY', zipCode: '10001' }, status: 'active', totalRentals: 8, totalSpent: 3100 },
  { firstName: 'Marcus', lastName: 'Johnson', email: 'marcus.j@email.com', phone: '+1-555-0103', driverLicense: 'DL-TX-345678', licenseExpiry: new Date('2027-02-20'), dateOfBirth: new Date('1985-11-05'), address: { street: '789 Elm Blvd', city: 'Houston', state: 'TX', zipCode: '77001' }, status: 'active', totalRentals: 22, totalSpent: 8750 },
  { firstName: 'Olivia', lastName: 'Brown', email: 'olivia.b@email.com', phone: '+1-555-0104', driverLicense: 'DL-FL-901234', licenseExpiry: new Date('2026-05-18'), dateOfBirth: new Date('1995-01-29'), address: { street: '321 Pine Road', city: 'Miami', state: 'FL', zipCode: '33101' }, status: 'active', totalRentals: 5, totalSpent: 1850 },
  { firstName: 'Ethan', lastName: 'Davis', email: 'ethan.d@email.com', phone: '+1-555-0105', driverLicense: 'DL-WA-567890', licenseExpiry: new Date('2025-09-10'), dateOfBirth: new Date('1990-06-17'), address: { street: '654 Maple Ave', city: 'Seattle', state: 'WA', zipCode: '98101' }, status: 'active', totalRentals: 15, totalSpent: 6200 },
  { firstName: 'Isabella', lastName: 'Martinez', email: 'isabella.m@email.com', phone: '+1-555-0106', driverLicense: 'DL-IL-234567', licenseExpiry: new Date('2026-12-01'), dateOfBirth: new Date('1993-09-08'), address: { street: '987 Cedar Lane', city: 'Chicago', state: 'IL', zipCode: '60601' }, status: 'active', totalRentals: 3, totalSpent: 980 }
];

async function seed() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log('Connected to MongoDB for seeding...');

    await Promise.all([User.deleteMany(), Car.deleteMany(), Customer.deleteMany(), Booking.deleteMany()]);
    console.log('Cleared existing data');

    // Create admin user
    const admin = await User.create({
      name: 'Admin User',
      email: 'admin@carrental.com',
      password: 'Admin123!',
      role: 'admin'
    });
    console.log('Admin user created: admin@carrental.com / Admin123!');

    await User.create({
      name: 'Manager User',
      email: 'manager@carrental.com',
      password: 'Manager123!',
      role: 'manager'
    });

    const createdCars = await Car.insertMany(cars);
    console.log(`Created ${createdCars.length} cars`);

    const createdCustomers = await Customer.insertMany(customers);
    console.log(`Created ${createdCustomers.length} customers`);

    // Create sample bookings
    const bookingData = [
      { customer: createdCustomers[0]._id, car: createdCars[0]._id, startDate: new Date('2024-01-10'), endDate: new Date('2024-01-15'), pickupLocation: 'Main Branch', returnLocation: 'Main Branch', status: 'completed', dailyRate: 150, totalDays: 5, subtotal: 750, taxes: 75, totalAmount: 825, paymentStatus: 'paid', paymentMethod: 'card' },
      { customer: createdCustomers[1]._id, car: createdCars[2]._id, startDate: new Date(), endDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), pickupLocation: 'Airport', returnLocation: 'Airport', status: 'active', dailyRate: 180, totalDays: 3, subtotal: 540, taxes: 54, totalAmount: 594, paymentStatus: 'paid', paymentMethod: 'card' },
      { customer: createdCustomers[2]._id, car: createdCars[8]._id, startDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), endDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), pickupLocation: 'Main Branch', returnLocation: 'Main Branch', status: 'confirmed', dailyRate: 120, totalDays: 3, subtotal: 360, taxes: 36, totalAmount: 396, paymentStatus: 'pending', paymentMethod: 'card' },
      { customer: createdCustomers[3]._id, car: createdCars[1]._id, startDate: new Date('2024-02-05'), endDate: new Date('2024-02-10'), pickupLocation: 'Downtown', returnLocation: 'Downtown', status: 'completed', dailyRate: 200, totalDays: 5, subtotal: 1000, taxes: 100, totalAmount: 1100, paymentStatus: 'paid', paymentMethod: 'bank_transfer' },
      { customer: createdCustomers[4]._id, car: createdCars[4]._id, startDate: new Date('2024-03-12'), endDate: new Date('2024-03-18'), pickupLocation: 'Main Branch', returnLocation: 'Airport', status: 'completed', dailyRate: 220, totalDays: 6, subtotal: 1320, taxes: 132, totalAmount: 1452, paymentStatus: 'paid', paymentMethod: 'card' }
    ];

    const createdBookings = await Booking.insertMany(bookingData);
    console.log(`Created ${createdBookings.length} bookings`);

    console.log('\n✅ Database seeded successfully!');
    console.log('Login credentials:');
    console.log('  Admin: admin@carrental.com / Admin123!');
    console.log('  Manager: manager@carrental.com / Manager123!');
    process.exit(0);
  } catch (error) {
    console.error('Seeding error:', error);
    process.exit(1);
  }
}

seed();
