const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');
const Car = require('../models/Car');
const Customer = require('../models/Customer');
const { protect } = require('../middleware/auth');

// @GET /api/bookings
router.get('/', protect, async (req, res) => {
  try {
    const { status, page = 1, limit = 10, search } = req.query;
    let query = {};
    if (status) query.status = status;

    const bookings = await Booking.find(query)
      .populate('customer', 'firstName lastName email phone')
      .populate('car', 'name brand model licensePlate image category')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    const total = await Booking.countDocuments(query);
    res.json({
      success: true,
      data: bookings,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / limit) }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @GET /api/bookings/:id
router.get('/:id', protect, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('customer')
      .populate('car')
      .populate('createdBy', 'name email');
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });
    res.json({ success: true, data: booking });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @POST /api/bookings
router.post('/', protect, async (req, res) => {
  try {
    const { car: carId, startDate, endDate, dailyRate } = req.body;
    const car = await Car.findById(carId);
    if (!car) return res.status(404).json({ success: false, message: 'Car not found' });
    if (car.status !== 'available') {
      return res.status(400).json({ success: false, message: 'Car is not available for rental' });
    }

    const start = new Date(startDate);
    const end = new Date(endDate);
    const totalDays = Math.ceil(Math.abs(end - start) / (1000 * 60 * 60 * 24));
    const subtotal = totalDays * dailyRate;
    const taxes = subtotal * 0.1;
    const totalAmount = subtotal + taxes + (req.body.additionalCharges || 0) - (req.body.discount || 0);

    const booking = await Booking.create({
      ...req.body,
      totalDays,
      subtotal,
      taxes,
      totalAmount,
      createdBy: req.user._id
    });

    // Update car status
    await Car.findByIdAndUpdate(carId, { status: 'reserved' });

    const populatedBooking = await Booking.findById(booking._id)
      .populate('customer', 'firstName lastName email phone')
      .populate('car', 'name brand model licensePlate image');

    res.status(201).json({ success: true, data: populatedBooking });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @PUT /api/bookings/:id
router.put('/:id', protect, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });

    const { status } = req.body;

    // Handle car status changes based on booking status
    if (status === 'active' && booking.status !== 'active') {
      await Car.findByIdAndUpdate(booking.car, { status: 'rented' });
    } else if ((status === 'completed' || status === 'cancelled') && booking.status !== status) {
      await Car.findByIdAndUpdate(booking.car, { status: 'available' });

      if (status === 'completed') {
        const car = await Car.findById(booking.car);
        await Car.findByIdAndUpdate(booking.car, {
          $inc: { totalEarnings: booking.totalAmount, totalRentals: 1 }
        });
        await Customer.findByIdAndUpdate(booking.customer, {
          $inc: { totalRentals: 1, totalSpent: booking.totalAmount }
        });
      }
    }

    const updatedBooking = await Booking.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    ).populate('customer', 'firstName lastName email phone')
     .populate('car', 'name brand model licensePlate image');

    res.json({ success: true, data: updatedBooking });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @DELETE /api/bookings/:id
router.delete('/:id', protect, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });
    if (['active', 'completed'].includes(booking.status)) {
      return res.status(400).json({ success: false, message: 'Cannot delete active or completed bookings' });
    }
    await Car.findByIdAndUpdate(booking.car, { status: 'available' });
    await Booking.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Booking deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
