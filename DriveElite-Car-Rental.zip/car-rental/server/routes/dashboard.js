const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');
const Car = require('../models/Car');
const Customer = require('../models/Customer');
const { protect } = require('../middleware/auth');

// @GET /api/dashboard/stats
router.get('/stats', protect, async (req, res) => {
  try {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);

    // Current month revenue
    const currentMonthRevenue = await Booking.aggregate([
      { $match: { status: 'completed', createdAt: { $gte: startOfMonth } } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } }
    ]);

    // Last month revenue
    const lastMonthRevenue = await Booking.aggregate([
      { $match: { status: 'completed', createdAt: { $gte: startOfLastMonth, $lte: endOfLastMonth } } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } }
    ]);

    const [totalCars, availableCars, rentedCars, totalCustomers, activeBookings] = await Promise.all([
      Car.countDocuments(),
      Car.countDocuments({ status: 'available' }),
      Car.countDocuments({ status: 'rented' }),
      Customer.countDocuments(),
      Booking.countDocuments({ status: { $in: ['active', 'confirmed'] } })
    ]);

    const totalRevenue = await Booking.aggregate([
      { $match: { status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } }
    ]);

    const currRevenue = currentMonthRevenue[0]?.total || 0;
    const lastRevenue = lastMonthRevenue[0]?.total || 1;
    const revenueGrowth = ((currRevenue - lastRevenue) / lastRevenue * 100).toFixed(1);

    res.json({
      success: true,
      data: {
        totalCars,
        availableCars,
        rentedCars,
        totalCustomers,
        activeBookings,
        totalRevenue: totalRevenue[0]?.total || 0,
        monthlyRevenue: currRevenue,
        revenueGrowth: parseFloat(revenueGrowth)
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @GET /api/dashboard/revenue-chart
router.get('/revenue-chart', protect, async (req, res) => {
  try {
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      const start = new Date(date.getFullYear(), date.getMonth(), 1);
      const end = new Date(date.getFullYear(), date.getMonth() + 1, 0);
      months.push({ start, end, label: start.toLocaleString('default', { month: 'short', year: '2-digit' }) });
    }

    const revenueData = await Promise.all(months.map(async ({ start, end, label }) => {
      const result = await Booking.aggregate([
        { $match: { status: 'completed', createdAt: { $gte: start, $lte: end } } },
        { $group: { _id: null, revenue: { $sum: '$totalAmount' }, bookings: { $sum: 1 } } }
      ]);
      return { month: label, revenue: result[0]?.revenue || 0, bookings: result[0]?.bookings || 0 };
    }));

    res.json({ success: true, data: revenueData });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @GET /api/dashboard/recent-bookings
router.get('/recent-bookings', protect, async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate('customer', 'firstName lastName email')
      .populate('car', 'name brand model image')
      .sort({ createdAt: -1 })
      .limit(8);
    res.json({ success: true, data: bookings });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @GET /api/dashboard/car-utilization
router.get('/car-utilization', protect, async (req, res) => {
  try {
    const categoryStats = await Car.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 }, available: { $sum: { $cond: [{ $eq: ['$status', 'available'] }, 1, 0] } }, rented: { $sum: { $cond: [{ $eq: ['$status', 'rented'] }, 1, 0] } } } }
    ]);
    res.json({ success: true, data: categoryStats });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
