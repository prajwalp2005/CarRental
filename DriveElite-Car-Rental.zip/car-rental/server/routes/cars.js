const express = require('express');
const router = express.Router();
const Car = require('../models/Car');
const { protect } = require('../middleware/auth');

// @GET /api/cars
router.get('/', protect, async (req, res) => {
  try {
    const { status, category, search, page = 1, limit = 10 } = req.query;
    let query = {};
    if (status) query.status = status;
    if (category) query.category = category;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { brand: { $regex: search, $options: 'i' } },
        { model: { $regex: search, $options: 'i' } },
        { licensePlate: { $regex: search, $options: 'i' } }
      ];
    }
    const total = await Car.countDocuments(query);
    const cars = await Car.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));
    res.json({
      success: true,
      data: cars,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / limit) }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @GET /api/cars/:id
router.get('/:id', protect, async (req, res) => {
  try {
    const car = await Car.findById(req.params.id);
    if (!car) return res.status(404).json({ success: false, message: 'Car not found' });
    res.json({ success: true, data: car });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @POST /api/cars
router.post('/', protect, async (req, res) => {
  try {
    const car = await Car.create(req.body);
    res.status(201).json({ success: true, data: car });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'License plate already exists' });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});

// @PUT /api/cars/:id
router.put('/:id', protect, async (req, res) => {
  try {
    const car = await Car.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!car) return res.status(404).json({ success: false, message: 'Car not found' });
    res.json({ success: true, data: car });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @DELETE /api/cars/:id
router.delete('/:id', protect, async (req, res) => {
  try {
    const car = await Car.findByIdAndDelete(req.params.id);
    if (!car) return res.status(404).json({ success: false, message: 'Car not found' });
    res.json({ success: true, message: 'Car deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @GET /api/cars/stats/overview
router.get('/stats/overview', protect, async (req, res) => {
  try {
    const stats = await Car.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]);
    const categoryStats = await Car.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 }, avgRate: { $avg: '$dailyRate' } } }
    ]);
    res.json({ success: true, data: { statusStats: stats, categoryStats } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
